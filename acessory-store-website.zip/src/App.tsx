import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { HealthcareSection } from './components/HealthcareSection';
import { PersonalizerStudio } from './components/PersonalizerStudio';
import { CatalogSection } from './components/CatalogSection';
import { OrderingSteps } from './components/OrderingSteps';
import { WhyUs } from './components/WhyUs';
import { GalleryLookbook } from './components/GalleryLookbook';
import { SocialFeeds } from './components/SocialFeeds';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { OrderModal } from './components/OrderModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Product } from './types';

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [orderItemName, setOrderItemName] = useState<string | undefined>(undefined);

  const handleOpenOrderModal = (productName?: string) => {
    setOrderItemName(productName);
    setOrderModalOpen(true);
  };

  const handleCloseOrderModal = () => {
    setOrderModalOpen(false);
    setOrderItemName(undefined);
  };

  const handleSelectForCustomizer = (itemType: string, emblem: string) => {
    const el = document.getElementById('personalizar');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0B0C] text-[#F3F3F1] selection:bg-[#C5A059] selection:text-black">
      {/* Fixed Navigation */}
      <Navbar onOpenOrderModal={handleOpenOrderModal} />

      <main>
        {/* Hero Section */}
        <Hero onOpenOrderModal={handleOpenOrderModal} />

        {/* About Section */}
        <AboutSection />

        {/* Specialized Healthcare Section */}
        <HealthcareSection 
          onOpenOrderModal={handleOpenOrderModal}
          onSelectForCustomizer={handleSelectForCustomizer}
        />

        {/* Interactive Customizer Studio */}
        <PersonalizerStudio onOpenOrderModal={handleOpenOrderModal} />

        {/* Full Filterable Catalog */}
        <CatalogSection 
          onOpenProductDetails={(prod) => setSelectedProduct(prod)}
          onOpenOrderModal={handleOpenOrderModal}
        />

        {/* Step-by-Step Ordering Guide */}
        <OrderingSteps onOpenOrderModal={() => handleOpenOrderModal('Personalização Sob Medida')} />

        {/* Brand Pillars */}
        <WhyUs />

        {/* Visual Lookbook & Lightbox */}
        <GalleryLookbook />

        {/* Official Social Feeds (Instagram, TikTok, Facebook) */}
        <SocialFeeds />

        {/* Contact, Camama Location & Direct Inquiry Form */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals & Overlays */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenOrderModal={handleOpenOrderModal}
      />

      <OrderModal
        isOpen={orderModalOpen}
        onClose={handleCloseOrderModal}
        productName={orderItemName}
      />

      {/* Floating WhatsApp Action */}
      <FloatingWhatsApp />
    </div>
  );
}
