import { Product, GalleryItem } from '../types';

export const STORE_INFO = {
  name: 'ACESSORY STORE',
  tagline: 'Estilo que representa quem você é',
  headline: 'Semijoias Personalizadas & Crachás Profissionais',
  location: 'Rotunda do Camama, Luanda, Angola',
  locationShort: 'Camama, Luanda',
  country: 'Angola',
  email: 'acessorystore0@gmail.com',
  whatsapp1: {
    display: '+244 941 411 375',
    clean: '244941411375',
    link: 'https://wa.me/244941411375',
  },
  whatsapp2: {
    display: '+244 936 202 630',
    clean: '244936202630',
    link: 'https://wa.me/244936202630',
  },
  social: {
    instagram: {
      handle: '@acessory_store21',
      url: 'https://www.instagram.com/acessory_store21/',
    },
    tiktok: {
      handle: '@acessorystore21',
      url: 'https://www.tiktok.com/@acessorystore21',
    },
    facebook: {
      name: 'ACESSORY STORE Oficial',
      url: 'https://web.facebook.com/profile.php?id',
    },
  },
};

export const IMAGES = {
  hero: '/src/assets/images/hero_luxury_jewelry_1790888041290.jpg',
  healthcareBadges: '/src/assets/images/healthcare_badges_showcase_1790888052778.jpg',
  jewelryDetail: '/src/assets/images/custom_jewelry_detail_1790888063057.jpg',
  kitNavy: '/src/assets/images/kit_executivo_azul_marinho_1790889272073.jpg',
  kitBlackKassongo: '/src/assets/images/kit_executivo_preto_luxo_1790889281577.jpg',
  crownPenSet: '/src/assets/images/caneta_coroa_dourada_luxo_1790889292236.jpg',
  kitCompact: '/src/assets/images/kit_corporativo_compacto_1790889302223.jpg',
};

export const PRODUCTS: Product[] = [
  {
    id: 'kit-executivo-vip-kassongo',
    name: 'Kit Executivo VIP Doutor (Dr. Ernesto Kassongo)',
    category: 'crachas_executivos',
    categoryLabel: 'Kits Executivos VIP',
    shortDescription: 'Conjunto completo de luxo em preto com gravação dourada: caderno com fivela, garrafa térmica, caneta com brasão, porta-cartões e pendrive USB.',
    description: 'Um dos produtos mais procurados da ACESSORY STORE em Luanda. Desenvolvido para médicos, doutores, advogados e executivos que exigem presença e sofisticação. Apresentado em estojo almofadado de alta qualidade.',
    image: IMAGES.kitBlackKassongo,
    materialsNote: 'Couro sintético nobre, aço inoxidável e gravação a laser permanente',
    customizationDetails: [
      'Gravação personalizada do nome completo com título (Ex: Dr. / Dra. / Eng.)',
      'Gravação vertical de destaque na garrafa térmica térmica vacuum',
      'Placa metálica espelhada no caderno e no porta-cartões',
      'Caneta executiva com brasão da profissão (Direito, Medicina, etc.)',
      'Pendrive metálico gravado'
    ],
    idealFor: 'Médicos, Advogados, Juízes, Diretores e Presentes Corporativos',
    isHighlight: true,
  },
  {
    id: 'kit-executivo-azul-marinho-ladislau',
    name: 'Kit Executivo Nobre Azul Marinho (Ladislau)',
    category: 'crachas_executivos',
    categoryLabel: 'Kits Executivos VIP',
    shortDescription: 'Caixa de apresentação em azul marinho com caderno texturizado, garrafa térmica, caneta, porta-cartões e chaveiro USB gravados.',
    description: 'Combinação refinada de tons azul marinho e detalhes acetinados. Cada componente é gravado com extrema nitidez, criando um presente inesquecível para formaturas, promoções e homenagens.',
    image: IMAGES.kitNavy,
    materialsNote: 'Acabamento premium azul marinho com gravação de alta resolução',
    customizationDetails: [
      'Personalização com o nome do cliente em todos os 5 itens',
      'Garrafa térmica com retenção prolongada de temperatura',
      'Caderno A5 com costura reforçada e fecho magnético',
      'Porta-cartões executivo com acabamento em metal escovado'
    ],
    idealFor: 'Executivos, Gestores, Formandos e Ocasiões Especiais',
    isHighlight: true,
  },
  {
    id: 'conjunto-caneta-coroa-real',
    name: 'Conjunto Caneta Coroa Real & Porta-Cartões (Dr. Helder António)',
    category: 'personalizados',
    categoryLabel: 'Canetas & Acessórios',
    shortDescription: 'Caneta banhada a ouro 24k com detalhe de coroa cravejada com pedras de brilho e porta-cartões em tecido nobre cinza com placa gravada.',
    description: 'A jóia das canetas executivas de Luanda. Apresentada em caixa estojo com forro de cetim, combina imponência e refinamento para assinaturas solenes e recepções importantes.',
    image: IMAGES.crownPenSet,
    materialsNote: 'Metal polido dourado de alto brilho e porta-cartões com estrutura rígida',
    customizationDetails: [
      'Gravação do nome em caligrafia cursiva no corpo da caneta',
      'Gravação na placa dourada do porta-cartões',
      'Estojo de luxo forrado com laço de cetim'
    ],
    idealFor: 'Assinatura de contratos, médicos, juízes e presentes elegantes',
    isHighlight: true,
  },
  {
    id: 'kit-corporativo-miguel-maria',
    name: 'Kit Executivo 4 Peças (Miguel Maria)',
    category: 'crachas_executivos',
    categoryLabel: 'Kits Executivos',
    shortDescription: 'Kit compacto com caderno executivo preto, caneta metálica fina, porta-cartões e porta-chaves com gravação em placa de metal.',
    description: 'Conjunto prático e altamente profissional para o dia a dia de trabalho em escritórios e consultórios em Luanda. Todos os itens combinados em estojo recortado a laser.',
    image: IMAGES.kitCompact,
    materialsNote: 'Couro preto fosco, metal espelhado e costura reforçada',
    customizationDetails: [
      'Gravação personalizada do nome nas 4 peças',
      'Porta-chaves elegante em couro e metal',
      'Porta-cartões com trava segura'
    ],
    idealFor: 'Brindes corporativos de alto padrão e uso pessoal',
  },
  {
    id: 'kit-oficial-acessory-store-06',
    name: 'Kit Oficial Assinatura ACESSORY STORE (Modelo 06)',
    category: 'personalizados',
    categoryLabel: 'Edição Especial',
    shortDescription: 'Kit de 4 peças com gravação sob medida do logotipo ou nome do cliente em estojo de apresentação com o selo dourado da marca.',
    description: 'Modelo emblemático da ACESSORY STORE. Permite estampar o brasão da sua empresa, consultório ou o seu próprio nome para uso pessoal ou presentes de colaboradores.',
    image: IMAGES.kitCompact,
    materialsNote: 'Conjunto completo em caixa rígida acolchoada',
    customizationDetails: [
      'Logotipo institucional ou nome pessoal gravado',
      'Caderno com fecho magnético',
      'Caneta com escrita fluida e acabamento acetinado'
    ],
    idealFor: 'Empresas, consultórios e clientes institucionais',
  },
  {
    id: 'cracha-saude-ouro-luxo',
    name: 'Crachá Luxo para Profissionais de Saúde',
    category: 'crachas_saude',
    categoryLabel: 'Crachás de Saúde',
    shortDescription: 'Acabamento espelhado dourado de alta precisão com nome, especialidade e brasão médico/hospitalar.',
    description: 'Desenvolvido especialmente para médicos, enfermeiros e especialistas em Luanda que desejam uma identificação que transmita autoridade e respeito. Possui fixação por íman duplo de neodímio que não fura jalecos.',
    image: IMAGES.healthcareBadges,
    materialsNote: 'Placa resistente com acabamento nobre e película protetora',
    customizationDetails: [
      'Gravação do Nome Completo ou Tratamento (Dr. / Dra. / Enf.)',
      'Especialidade ou Cargo Hospitalar',
      'Símbolo ou brasão da profissão (Medicina, Enfermagem, Odonto, Fisioterapia, etc.)',
      'Fixação por Íman Duplo de Alta Força'
    ],
    idealFor: 'Médicos, Cirurgiões, Enfermeiros, Farmacêuticos, Fisioterapeutas',
    isHighlight: true,
  },
  {
    id: 'colar-nome-personalizado',
    name: 'Colar Personalizado com Nome em Caligrafia Nobre',
    category: 'semijoias',
    categoryLabel: 'Semijoias',
    shortDescription: 'Colar com nome recortado e acabamento banhado a ouro champagne de alto brilho.',
    description: 'A peça assinatura de joalheria personalizada da ACESSORY STORE. Traduz seu nome ou de quem você ama em uma joia brilhante e marcante para o dia a dia.',
    image: IMAGES.hero,
    materialsNote: 'Semijoia com banho nobre e verniz antialérgico de alta durabilidade',
    customizationDetails: [
      'Qualquer nome ou palavra de significado',
      'Opção com pingente de ponto de luz de zircônia',
      'Comprimento de corrente ajustável'
    ],
    idealFor: 'Uso pessoal diário e presentes afetivos',
    isHighlight: true,
  },
  {
    id: 'pulseira-placa-identidade',
    name: 'Pulseira com Placa Personalizada Gravada',
    category: 'semijoias',
    categoryLabel: 'Semijoias',
    shortDescription: 'Pulseira contemporânea em elos delicados com placa espelhada gravada a laser.',
    description: 'Joia atemporal que combina sofisticação e sentimento. Pode receber gravação de iniciais, nomes de filhos, datas comemorativas ou uma palavra de fé.',
    image: IMAGES.jewelryDetail,
    materialsNote: 'Elo com placa espelhada polida à mão',
    customizationDetails: [
      'Gravação frente e verso opcional',
      'Iniciais, datas ou pequenos símbolos afetivos',
      'Ajuste para qualquer tamanho de pulso'
    ],
    idealFor: 'Mulheres e homens de bom gosto',
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Kit Executivo VIP Doutor (Dr. Ernesto Kassongo)',
    category: 'Kits Executivos Reais',
    image: IMAGES.kitBlackKassongo,
    caption: 'Caixa de apresentação em preto com caderno, garrafa térmica, caneta e porta-cartões gravados.',
    isWide: true,
  },
  {
    id: 'gal-2',
    title: 'Kit Executivo Nobre Azul Marinho (Ladislau)',
    category: 'Personalização Exclusiva',
    image: IMAGES.kitNavy,
    caption: 'Tons azul marinho com garrafa vacuum e gravação a laser personalizada em Luanda.',
  },
  {
    id: 'gal-3',
    title: 'Caneta Real Coroa Dourada & Estojo',
    category: 'Canetas de Luxo',
    image: IMAGES.crownPenSet,
    caption: 'Coroa de pedrarias cravejadas e escrita macia com porta-cartões cinza nobre.',
  },
  {
    id: 'gal-4',
    title: 'Crachás de Saúde & Medicina com Íman',
    category: 'Linha Médica',
    image: IMAGES.healthcareBadges,
    caption: 'Fixação magnética potente que preserva os jalecos dos médicos e enfermeiros.',
  },
  {
    id: 'gal-5',
    title: 'Kit Executivo 4 Peças (Miguel Maria)',
    category: 'Linha Corporativa',
    image: IMAGES.kitCompact,
    caption: 'Caderno, caneta, porta-chaves e porta-cartões com gravação permanente.',
    isWide: true,
  },
  {
    id: 'gal-6',
    title: 'Semijoias Nobres Sob Encomenda',
    category: 'Semijoias & Design',
    image: IMAGES.hero,
    caption: 'Colares de nome e berloques com acabamento em ouro champagne.',
  }
];

export const PILLARS = [
  {
    number: '01',
    title: 'Personalização Singular',
    description: 'Peças feitas sob medida que traduzem nomes, momentos e profissões em algo tangível e inesquecível.',
  },
  {
    number: '02',
    title: 'Estilo & Sofisticação',
    description: 'Design moderno com proporções harmoniosas, brilho refinado e acabamento que valoriza qualquer vestimenta.',
  },
  {
    number: '03',
    title: 'Profissionalismo Comprovado',
    description: 'Soluções desenvolvidas para ambientes exigentes, com especial carinho pelos heróis da saúde em Angola.',
  },
  {
    number: '04',
    title: 'Identidade & Expressão',
    description: 'Mais do que simples acessórios: criamos símbolos de respeito, vocação e orgulho pelo que você construiu.',
  },
];

export const STEPS = [
  {
    step: '1',
    title: 'Escolha a Peça',
    description: 'Selecione entre colares, pulseiras, crachás profissionais de saúde ou corporativos.',
  },
  {
    step: '2',
    title: 'Defina a Personalização',
    description: 'Indique o nome, profissão, especialidade ou símbolo desejado para a gravação.',
  },
  {
    step: '3',
    title: 'Envie para Confirmação',
    description: 'Converse diretamente conosco pelo WhatsApp oficial para validação da arte e detalhes.',
  },
  {
    step: '4',
    title: 'Receba com Orgulho',
    description: 'Produção cuidadosa com entrega facilitada em Luanda e pontos combinados.',
  },
];
