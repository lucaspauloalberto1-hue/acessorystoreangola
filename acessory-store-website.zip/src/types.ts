export type ProductCategory = 'todos' | 'semijoias' | 'crachas_saude' | 'crachas_executivos' | 'personalizados';

export interface Product {
  id: string;
  name: string;
  category: 'semijoias' | 'crachas_saude' | 'crachas_executivos' | 'personalizados';
  categoryLabel: string;
  shortDescription: string;
  description: string;
  image: string;
  materialsNote: string;
  customizationDetails: string[];
  price?: string; // only if confirmed, otherwise "Sob Consulta / Personalizado"
  isHighlight?: boolean;
  idealFor?: string;
}

export interface CustomizationState {
  itemType: 'cracha_saude' | 'cracha_executivo' | 'colar_nome' | 'pulseira_placa' | 'porta_cracha';
  nameText: string;
  subText: string; // e.g. "Médica Cirurgiã", "Enfermeira Chefe", "Advogada"
  finish: 'dourado' | 'prata' | 'dourado_rose';
  emblem: 'medicina' | 'enfermagem' | 'odontologia' | 'direito' | 'farmacia' | 'coracao' | 'nenhum';
  fastener: 'iman' | 'alfinete' | 'cordao' | 'clip_retratil';
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  caption: string;
  isWide?: boolean;
}
