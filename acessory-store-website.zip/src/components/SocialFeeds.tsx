import React from 'react';
import { STORE_INFO } from '../data/storeData';
import { Instagram, Video, Facebook, Mail, ArrowUpRight } from 'lucide-react';

export const SocialFeeds: React.FC = () => {
  return (
    <section className="py-24 bg-[#0B0B0C] border-t border-[#1C1C20] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
            <Instagram className="w-4 h-4 text-[#C5A059]" />
            <span>Redes Sociais Oficiais</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light mb-4">
            Acompanhe a Nossa Marca
          </h2>

          <p className="text-sm text-[#A1A1AA] leading-relaxed text-balance">
            Fique por dentro das novidades, entregas recentes em Luanda, bastidores de produção e depoimentos de quem escolheu a ACESSORY STORE.
          </p>
        </div>

        {/* Social Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* 1. Instagram Card */}
          <div className="p-8 bg-[#121215] border border-[#232328] hover:border-[#C5A059]/50 transition-all flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] flex items-center justify-center text-white shadow-md">
                  <Instagram className="w-6 h-6" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-[#71717A] group-hover:text-[#C5A059] transition-colors" />
              </div>

              <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block mb-1">
                Instagram Oficial
              </span>
              <h3 className="font-serif text-2xl text-[#FBFBF9] mb-3">
                {STORE_INFO.social.instagram.handle}
              </h3>
              <p className="text-xs text-[#8E8E93] leading-relaxed">
                Fotos diárias dos modelos entregues, feedback de clientes em Luanda e destaques dos novos modelos de crachás de saúde.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-[#232328]">
              <a
                href={STORE_INFO.social.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors flex items-center justify-center gap-2"
              >
                <span>Ver no Instagram</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* 2. TikTok Card */}
          <div className="p-8 bg-[#121215] border border-[#232328] hover:border-[#C5A059]/50 transition-all flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-12 h-12 rounded-full bg-[#000000] border border-[#27272A] flex items-center justify-center text-white shadow-md">
                  <Video className="w-6 h-6 text-[#25F4EE]" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-[#71717A] group-hover:text-[#C5A059] transition-colors" />
              </div>

              <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block mb-1">
                TikTok Oficial
              </span>
              <h3 className="font-serif text-2xl text-[#FBFBF9] mb-3">
                {STORE_INFO.social.tiktok.handle}
              </h3>
              <p className="text-xs text-[#8E8E93] leading-relaxed">
                Vídeos dos detalhes de brilho, teste da fixação por íman e o processo minucioso de personalização de cada acessório.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-[#232328]">
              <a
                href={STORE_INFO.social.tiktok.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 text-xs uppercase tracking-widest font-semibold text-[#F4F4F5] bg-[#1E1E22] hover:bg-[#2A2A30] border border-[#3F3F46] transition-colors flex items-center justify-center gap-2"
              >
                <span>Seguir no TikTok</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* 3. Facebook Card */}
          <div className="p-8 bg-[#121215] border border-[#232328] hover:border-[#C5A059]/50 transition-all flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-12 h-12 rounded-full bg-[#1877F2] flex items-center justify-center text-white shadow-md">
                  <Facebook className="w-6 h-6" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-[#71717A] group-hover:text-[#C5A059] transition-colors" />
              </div>

              <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block mb-1">
                Facebook Oficial
              </span>
              <h3 className="font-serif text-2xl text-[#FBFBF9] mb-3">
                Página Oficial
              </h3>
              <p className="text-xs text-[#8E8E93] leading-relaxed">
                Acompanhe as publicações institucionais, eventos corporativos e novidades da loja no Facebook de Angola.
              </p>
            </div>

            <div className="mt-8 pt-4 border-t border-[#232328]">
              <a
                href={STORE_INFO.social.facebook.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 text-xs uppercase tracking-widest font-semibold text-[#F4F4F5] bg-[#1E1E22] hover:bg-[#2A2A30] border border-[#3F3F46] transition-colors flex items-center justify-center gap-2"
              >
                <span>Acessar Facebook</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
