import React from 'react';
import { Product } from '../types';
import { STORE_INFO } from '../data/storeData';
import { X, Sparkles, MessageCircle, Instagram, ShieldCheck, Check } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onOpenOrderModal: (productName: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onOpenOrderModal,
}) => {
  if (!product) return null;

  const handleWhatsAppDirect = (number: string) => {
    const text = encodeURIComponent(
      `Olá ACESSORY STORE! Gostaria de mais informações e fazer o pedido da peça: *${product.name}*.\n\nComo procedemos para a personalização e entrega em Luanda?`
    );
    window.open(`https://wa.me/${number}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#141417] border border-[#27272A] shadow-2xl my-8 overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-[#A1A1AA] hover:text-[#F4F4F5] bg-black/60 rounded-full transition-colors"
          aria-label="Fechar detalhes"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Product Image Slot */}
          <div className="relative aspect-square md:aspect-auto overflow-hidden bg-[#18181B]">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent md:hidden" />
          </div>

          {/* Details Content */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold">
                  {product.categoryLabel}
                </span>
                {product.price && (
                  <span className="text-sm font-semibold font-mono text-[#F4F4F5] bg-[#222226] px-2.5 py-1 border border-[#383840]">
                    {product.price}
                  </span>
                )}
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl text-[#FBFBF9] leading-tight">
                {product.name}
              </h3>

              <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
                {product.description}
              </p>

              {/* Customization Details */}
              <div className="space-y-2 pt-2 border-t border-[#26262B]">
                <h4 className="text-xs uppercase tracking-wider text-[#F4F4F5] font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Opções de Personalização</span>
                </h4>
                <ul className="space-y-1.5">
                  {product.customizationDetails.map((detail, idx) => (
                    <li key={idx} className="text-xs text-[#8E8E93] flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Materials & Guarantee Note */}
              <div className="pt-2 text-xs text-[#71717A] flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <span>{product.materialsNote} · Produção e acabamento sob medida.</span>
              </div>

            </div>

            {/* Ordering Action Options */}
            <div className="mt-8 pt-6 border-t border-[#26262B] space-y-3">
              <p className="text-xs font-medium text-[#F4F4F5] uppercase tracking-wider">
                Como deseja encomendar?
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleWhatsAppDirect(STORE_INFO.whatsapp1.clean)}
                  className="py-2.5 px-3 text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" />
                  <span>WhatsApp 1</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleWhatsAppDirect(STORE_INFO.whatsapp2.clean)}
                  className="py-2.5 px-3 text-xs uppercase tracking-wider font-semibold text-[#F4F4F5] bg-[#1E1E22] hover:bg-[#2A2A30] border border-[#3F3F46] transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 shrink-0 text-[#C5A059]" />
                  <span>WhatsApp 2</span>
                </button>
              </div>

              <a
                href={STORE_INFO.social.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 text-xs uppercase tracking-wider font-medium text-[#A1A1AA] hover:text-[#FFFFFF] bg-transparent hover:bg-white/5 border border-[#27272A] transition-colors flex items-center justify-center gap-2"
              >
                <Instagram className="w-4 h-4 text-[#E1306C]" />
                <span>Conversar pelo Instagram ({STORE_INFO.social.instagram.handle})</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
