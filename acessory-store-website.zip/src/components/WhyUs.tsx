import React from 'react';
import { PILLARS } from '../data/storeData';
import { Sparkles, Gem, ShieldCheck, HeartHandshake } from 'lucide-react';

export const WhyUs: React.FC = () => {
  const icons = [Sparkles, Gem, ShieldCheck, HeartHandshake];

  return (
    <section className="py-24 bg-[#0B0B0C] border-t border-[#1C1C20]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
            Valores & Excelência
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light leading-tight">
            Por que Escolher a ACESSORY STORE
          </h2>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PILLARS.map((pillar, idx) => {
            const Icon = icons[idx];
            return (
              <div
                key={pillar.number}
                className="p-8 bg-[#121215] border border-[#232328] hover:border-[#C5A059]/40 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif text-3xl text-[#C5A059] font-light">
                      {pillar.number}
                    </span>
                    <Icon className="w-5 h-5 text-[#C5A059]/70" />
                  </div>

                  <h3 className="font-serif text-xl text-[#FBFBF9] mb-3">
                    {pillar.title}
                  </h3>

                  <p className="text-xs text-[#8E8E93] leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="mt-8 pt-4 border-t border-[#232328] text-[11px] text-[#52525B] uppercase tracking-wider">
                  Pilar ACESSORY STORE
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
