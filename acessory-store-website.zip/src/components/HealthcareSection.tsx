import React from 'react';
import { IMAGES } from '../data/storeData';
import { Shield, Sparkles, CheckCircle2, HeartPulse, Magnet, Droplets, UserCheck } from 'lucide-react';

interface HealthcareSectionProps {
  onOpenOrderModal: (productName?: string) => void;
  onSelectForCustomizer: (itemType: string, emblem: string) => void;
}

export const HealthcareSection: React.FC<HealthcareSectionProps> = ({
  onOpenOrderModal,
  onSelectForCustomizer,
}) => {
  return (
    <section id="saude" className="py-24 bg-[#0B0B0C] border-t border-[#1F1F24] relative overflow-hidden">
      {/* Background Subtle Glow */}
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-[#C5A059]/5 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
            <HeartPulse className="w-4 h-4 text-[#C5A059]" />
            <span>Linha Exclusiva para a Área Médica & Hospitalar</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light leading-tight mb-6">
            Para quem cuida de vidas.
          </h2>

          <p className="text-base text-[#A1A1AA] leading-relaxed text-balance">
            Médicos, enfermeiros, cirurgiões, fisioterapeutas e profissionais da saúde merecem uma identificação que corresponda à nobreza da sua profissão. Criamos crachás personalizados que unem autoridade clínica, elegância e funcionalidade diária.
          </p>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          
          {/* Main Visual: Doctor Executive Kit Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] overflow-hidden border border-[#27272A] bg-[#141416]">
              <img
                src={IMAGES.kitBlackKassongo}
                alt="Kit Executivo Doutor Dr. Ernesto Kassongo com garrafa térmica, caderno, caneta e porta-cartões da ACESSORY STORE"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center filter brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
              
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-xs uppercase tracking-wider text-[#C5A059] font-medium block mb-1">
                  Kit Personalizado Doutor · Dr. Ernesto Kassongo
                </span>
                <p className="text-sm text-[#F4F4F5] font-light">
                  Conjunto de prestígio para médicos, diretores clínicos e especialistas com gravação a laser permanente.
                </p>
              </div>
            </div>
          </div>

          {/* Secondary Visual: Close-up of Badges */}
          <div className="lg:col-span-6 space-y-6">
            <div className="aspect-[16/10] overflow-hidden border border-[#27272A] bg-[#141416] relative">
              <img
                src={IMAGES.healthcareBadges}
                alt="Crachás profissionais de saúde com brasão médico em acabamento dourado"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-black/30 pointer-events-none" />
            </div>

            {/* Differentiating Factors for Hospital Environments */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-[#141417] border border-[#26262B]">
                <div className="flex items-center gap-2 mb-2 text-[#C5A059]">
                  <Magnet className="w-5 h-5 shrink-0" />
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#F4F4F5]">Íman Duplo Neodímio</span>
                </div>
                <p className="text-xs text-[#8E8E93] leading-relaxed">
                  Fixação magnética de alta potência que prende com segurança sem furar ou desfiar jalecos e scrubs.
                </p>
              </div>

              <div className="p-4 bg-[#141417] border border-[#26262B]">
                <div className="flex items-center gap-2 mb-2 text-[#C5A059]">
                  <Droplets className="w-5 h-5 shrink-0" />
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#F4F4F5]">Higienização Segura</span>
                </div>
                <p className="text-xs text-[#8E8E93] leading-relaxed">
                  Resistente a limpezas frequentes com álcool 70% e desinfetantes habituais da rotina hospitalar.
                </p>
              </div>

              <div className="p-4 bg-[#141417] border border-[#26262B]">
                <div className="flex items-center gap-2 mb-2 text-[#C5A059]">
                  <UserCheck className="w-5 h-5 shrink-0" />
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#F4F4F5]">Legibilidade Imediata</span>
                </div>
                <p className="text-xs text-[#8E8E93] leading-relaxed">
                  Tipografia nítida que facilita a identificação pelo paciente e pela equipa de plantão.
                </p>
              </div>

              <div className="p-4 bg-[#141417] border border-[#26262B]">
                <div className="flex items-center gap-2 mb-2 text-[#C5A059]">
                  <Sparkles className="w-5 h-5 shrink-0" />
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#F4F4F5]">Brasões de Todas as Áreas</span>
                </div>
                <p className="text-xs text-[#8E8E93] leading-relaxed">
                  Medicina, Enfermagem, Odontologia, Fisioterapia, Farmácia, Biomedicina e Nutrição.
                </p>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-4">
              <a
                href="#personalizar"
                onClick={() => onSelectForCustomizer('cracha_saude', 'medicina')}
                className="px-6 py-3.5 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors text-center"
              >
                Solicitar Personalização de Crachá
              </a>

              <button
                onClick={() => onOpenOrderModal('Crachá de Saúde Personalizado')}
                className="px-6 py-3.5 text-xs uppercase tracking-widest font-semibold text-[#E4E4E7] border border-[#3F3F46] hover:border-[#C5A059] hover:text-[#C5A059] transition-colors text-center"
              >
                Tirar Dúvidas via WhatsApp
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
