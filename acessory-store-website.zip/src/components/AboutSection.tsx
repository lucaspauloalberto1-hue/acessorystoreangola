import React from 'react';
import { IMAGES, STORE_INFO } from '../data/storeData';
import { Sparkles, ShieldCheck, HeartHandshake, Gem } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-[#0E0E10] border-t border-[#1C1C20] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Editorial Imagery */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] overflow-hidden border border-[#27272A] bg-[#141416]">
              <img
                src={IMAGES.jewelryDetail}
                alt="Detalhe de semijoias com acabamento nobre da ACESSORY STORE"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center filter brightness-90 hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute bottom-6 left-6 right-6">
                <p className="text-xs uppercase tracking-widest text-[#C5A059] font-medium mb-1">
                  Ateliê de Personalização · Luanda
                </p>
                <p className="text-sm text-[#E4E4E7] font-light">
                  Cada peça carrega a dedicação ao detalhe e o respeito pela sua história pessoal.
                </p>
              </div>
            </div>
            
            {/* Subtle decorative gold edge accent */}
            <div className="hidden sm:block absolute -bottom-4 -right-4 w-28 h-28 border-r-2 border-b-2 border-[#C5A059]/40 pointer-events-none" />
          </div>

          {/* Right Column: Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-block text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
              Identidade & Vocação
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] leading-tight text-balance">
              Mais do que acessórios. <br className="hidden sm:inline" />
              <span className="italic font-normal text-[#C5A059]">Identidade.</span>
            </h2>

            <p className="text-[#A1A1AA] text-base leading-relaxed">
              A <strong className="text-[#F4F4F5] font-medium">ACESSORY STORE</strong> nasceu da certeza de que os acessórios que escolhemos carregar dizem muito sobre quem somos. Em um mundo de padronização, a verdadeira sofisticação reside na singularidade.
            </p>

            <p className="text-[#A1A1AA] text-base leading-relaxed">
              Com presença em <span className="text-[#F4F4F5]">Luanda (Rotunda do Camama)</span>, unimos criatividade, design refinado e materiais nobres para criar peças com significado: desde colares e pulseiras gravadas com nomes e datas queridas, até crachás profissionais que consagram o orgulho de uma carreira.
            </p>

            {/* 4 Core Pillars Preview */}
            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-[#27272A]/70">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#C5A059] font-semibold">
                  <Gem className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Estilo Autêntico</span>
                </div>
                <p className="text-xs text-[#71717A] leading-normal">
                  Design contemporâneo que valoriza sua presença em qualquer ambiente.
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#C5A059] font-semibold">
                  <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Personalização</span>
                </div>
                <p className="text-xs text-[#71717A] leading-normal">
                  Nomes, profissões e elementos gravados com nitidez impecável.
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#C5A059] font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Profissionalismo</span>
                </div>
                <p className="text-xs text-[#71717A] leading-normal">
                  Identificações pensadas para atender as exigências médicas e corporativas.
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#C5A059] font-semibold">
                  <HeartHandshake className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>Afeto & Propósito</span>
                </div>
                <p className="text-xs text-[#71717A] leading-normal">
                  Cada pedido é trabalhado como uma celebração de uma conquista.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <a
                href="#personalizar"
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C5A059] hover:text-[#D4AF37] font-semibold underline underline-offset-8 transition-colors"
              >
                <span>Descubra como criar sua peça exclusiva</span>
                <span aria-hidden="true">&rarr;</span>
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
