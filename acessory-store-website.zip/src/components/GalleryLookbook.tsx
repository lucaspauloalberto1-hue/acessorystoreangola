import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data/storeData';
import { GalleryItem } from '../types';
import { X, ZoomIn, Eye, Sparkles } from 'lucide-react';

export const GalleryLookbook: React.FC = () => {
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  return (
    <section className="py-24 bg-[#0E0E10] border-t border-[#1C1C20]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#232328]">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
              Galeria Visual & Acabamentos
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light">
              Detalhes que Falam por Si
            </h2>
          </div>
          <p className="text-xs text-[#8E8E93] max-w-sm mt-3 md:mt-0">
            A estética das semijoias nobres e a precisão dos crachás em ação real no dia a dia angolano.
          </p>
        </div>

        {/* Masonry / Editorial Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-6">
          {GALLERY_ITEMS.map((item, index) => {
            // Asymmetric layout spans for editorial rhythm
            const colSpan = index === 0 ? 'lg:col-span-7' : index === 1 ? 'lg:col-span-5' : index === 2 ? 'lg:col-span-5' : 'lg:col-span-7';
            const aspect = index === 0 || index === 3 ? 'aspect-[16/10]' : 'aspect-[4/3]';

            return (
              <div
                key={item.id}
                className={`${colSpan} group relative bg-[#141417] border border-[#232328] overflow-hidden cursor-pointer`}
                onClick={() => setActiveItem(item)}
              >
                <div className={`relative ${aspect} overflow-hidden`}>
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-95"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                  {/* Hover Overlay with Zoom Icon */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    <div className="w-12 h-12 rounded-full bg-[#C5A059]/90 text-[#0B0B0C] flex items-center justify-center shadow-lg">
                      <ZoomIn className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Caption & Metadata */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <span className="text-[11px] uppercase tracking-wider text-[#C5A059] font-medium block mb-1">
                      {item.category}
                    </span>
                    <h3 className="font-serif text-lg text-[#FBFBF9] leading-snug">
                      {item.title}
                    </h3>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Lightbox Modal */}
      {activeItem && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md"
          onClick={() => setActiveItem(null)}
        >
          <div 
            className="relative max-w-4xl w-full bg-[#121215] border border-[#2A2A30] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setActiveItem(null)}
              className="absolute top-4 right-4 z-10 p-2 text-white/80 hover:text-white bg-black/60 rounded-full transition-colors"
              aria-label="Fechar ampliação"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="relative aspect-[16/10] bg-black">
              <img
                src={activeItem.image}
                alt={activeItem.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-[#232328]">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold block mb-1">
                  {activeItem.category} · ACESSORY STORE
                </span>
                <h4 className="font-serif text-xl sm:text-2xl text-[#FBFBF9]">
                  {activeItem.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#A1A1AA] mt-1">
                  {activeItem.caption}
                </p>
              </div>

              <a
                href="#personalizar"
                onClick={() => setActiveItem(null)}
                className="px-6 py-3 text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] whitespace-nowrap text-center transition-colors"
              >
                Personalizar Peça Similar
              </a>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
