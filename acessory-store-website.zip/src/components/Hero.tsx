import React from 'react';
import { IMAGES, STORE_INFO } from '../data/storeData';
import { ArrowRight, Sparkles } from 'lucide-react';

interface HeroProps {
  onOpenOrderModal: (productName?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenOrderModal }) => {
  return (
    <section className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden">
      {/* Background Photography with Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.hero}
          alt="Semijoias personalizadas em ouro da ACESSORY STORE Luanda"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center filter brightness-[0.45] scale-105 transform motion-safe:transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0C] via-[#0B0B0C]/60 to-black/70" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(197,160,89,0.08)_0%,transparent_70%)]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Subtle Brand Location Kicker */}
        <div className="inline-flex items-center gap-2 mb-6 text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          <span>Luanda, Angola</span>
          <span aria-hidden="true">·</span>
          <span>Semijoias Personalizadas & Design</span>
          <span aria-hidden="true">·</span>
          <span>Crachás Profissionais</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-serif font-light text-[#FBFBF9] tracking-wider mb-6 text-balance leading-tight">
          ACESSORY STORE
        </h1>

        {/* Subtitle */}
        <p className="max-w-2xl mx-auto text-lg sm:text-xl md:text-2xl font-light text-[#D4D4D8] mb-10 text-balance leading-relaxed">
          Estilo que representa quem você é.
        </p>

        <p className="max-w-xl mx-auto text-sm text-[#A1A1AA] mb-10 font-normal leading-relaxed">
          Semijoias exclusivas e crachás profissionais desenhados com acabamento nobre em Luanda. Peças sob medida que celebram sua vocação, seu nome e sua elegância.
        </p>

        {/* Primary Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6">
          <a
            href="#catalogo"
            className="w-full sm:w-auto px-8 py-4 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-all duration-200 text-center flex items-center justify-center gap-3 shadow-lg"
          >
            <span>Explorar Coleção</span>
            <ArrowRight className="w-4 h-4" />
          </a>

          <a
            href="#personalizar"
            className="w-full sm:w-auto px-8 py-4 text-xs uppercase tracking-widest font-semibold text-[#F5F4F0] border border-[#C5A059]/60 hover:border-[#C5A059] hover:bg-[#C5A059]/10 transition-all duration-200 text-center flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#C5A059]" />
            <span>Personalizar Agora</span>
          </a>
        </div>

        {/* Quiet Trust Bar */}
        <div className="mt-16 pt-8 border-t border-[#27272A]/70 flex flex-wrap items-center justify-center gap-8 text-xs text-[#71717A] tracking-wider uppercase font-medium">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
            <span>Atendimento em Luanda & Encomendas</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
            <span>Linha Especial para Profissionais de Saúde</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
            <span>Fixação Magnética Inovadora (Sem Furos)</span>
          </div>
        </div>
      </div>
    </section>
  );
};
