import React from 'react';
import { STORE_INFO } from '../data/storeData';
import { X, MessageCircle, Instagram, Mail, ShieldCheck } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  productName?: string;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  productName,
}) => {
  if (!isOpen) return null;

  const targetTitle = productName || 'Peça Personalizada';

  const handleWhatsApp = (number: string) => {
    const text = encodeURIComponent(
      `Olá ACESSORY STORE! Gostaria de fazer a encomenda de: *${targetTitle}*.\n\nComo procedemos com os dados para personalização e envio em Luanda?`
    );
    window.open(`https://wa.me/${number}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-[#141417] border border-[#27272A] p-6 sm:p-8 shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#A1A1AA] hover:text-[#F4F4F5] rounded-full transition-colors"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-8">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-semibold block mb-2">
            ACESSORY STORE · Luanda
          </span>
          <h3 className="font-serif text-2xl sm:text-3xl text-[#FBFBF9] mb-2">
            Como deseja fazer o seu pedido?
          </h3>
          <p className="text-xs sm:text-sm text-[#A1A1AA]">
            Item selecionado: <strong className="text-[#F4F4F5] font-semibold">{targetTitle}</strong>
          </p>
        </div>

        {/* Big Elegant Action Buttons */}
        <div className="space-y-3">
          
          {/* WhatsApp Line 1 */}
          <button
            onClick={() => handleWhatsApp(STORE_INFO.whatsapp1.clean)}
            className="w-full p-4 text-left bg-[#1B1B1F] hover:bg-[#232328] border border-[#2E2E35] hover:border-[#C5A059] transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-colors">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block">WhatsApp Oficial (Linha 1)</span>
                <span className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp1.display}</span>
              </div>
            </div>
            <span className="text-xs text-[#C5A059] font-medium">&rarr;</span>
          </button>

          {/* WhatsApp Line 2 */}
          <button
            onClick={() => handleWhatsApp(STORE_INFO.whatsapp2.clean)}
            className="w-full p-4 text-left bg-[#1B1B1F] hover:bg-[#232328] border border-[#2E2E35] hover:border-[#C5A059] transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-colors">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block">WhatsApp Oficial (Linha 2)</span>
                <span className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp2.display}</span>
              </div>
            </div>
            <span className="text-xs text-[#C5A059] font-medium">&rarr;</span>
          </button>

          {/* Instagram Direct */}
          <a
            href={STORE_INFO.social.instagram.url}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full p-4 text-left bg-[#1B1B1F] hover:bg-[#232328] border border-[#2E2E35] hover:border-[#DD2A7B] transition-all flex items-center justify-between group block"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#F58529]/20 via-[#DD2A7B]/20 to-[#8134AF]/20 border border-[#DD2A7B]/40 flex items-center justify-center text-[#DD2A7B] group-hover:opacity-90">
                <Instagram className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block">Instagram Direct</span>
                <span className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.social.instagram.handle}</span>
              </div>
            </div>
            <span className="text-xs text-[#DD2A7B] font-medium">&rarr;</span>
          </a>

          {/* Email Option */}
          <a
            href={`mailto:${STORE_INFO.email}?subject=${encodeURIComponent(`Encomenda: ${targetTitle}`)}`}
            className="w-full p-4 text-left bg-[#1B1B1F] hover:bg-[#232328] border border-[#2E2E35] hover:border-[#A1A1AA] transition-all flex items-center justify-between group block"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-[#F4F4F5]">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider text-[#A1A1AA] block">Gmail da Empresa</span>
                <span className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.email}</span>
              </div>
            </div>
            <span className="text-xs text-[#A1A1AA] font-medium">&rarr;</span>
          </a>

        </div>

        <div className="mt-8 pt-4 border-t border-[#26262B] flex items-center justify-center gap-2 text-xs text-[#71717A]">
          <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
          <span>Localizados na Rotunda do Camama, Luanda, Angola</span>
        </div>

      </div>
    </div>
  );
};
