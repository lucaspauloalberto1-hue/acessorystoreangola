import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { MessageCircle, Menu, X } from 'lucide-react';

interface NavbarProps {
  onOpenOrderModal: (productName?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenOrderModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#0B0B0C]/90 backdrop-blur-md border-b border-[#262629]">
      {/* Top Bar Contract: 3 zones */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#" 
          className="text-2xl sm:text-3xl font-serif tracking-widest text-[#F5F4F0] hover:text-[#C5A059] transition-colors"
        >
          ACESSORY STORE
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs uppercase tracking-widest font-medium text-[#A1A1AA]">
          <a href="#sobre" className="hover:text-[#F5F4F0] transition-colors">Sobre</a>
          <a href="#semijoias" className="hover:text-[#F5F4F0] transition-colors">Semijoias</a>
          <a href="#saude" className="hover:text-[#F5F4F0] transition-colors">Área da Saúde</a>
          <a href="#personalizar" className="hover:text-[#F5F4F0] transition-colors">Personalização</a>
          <a href="#catalogo" className="hover:text-[#F5F4F0] transition-colors">Catálogo</a>
          <a href="#contacto" className="hover:text-[#F5F4F0] transition-colors">Contactos</a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onOpenOrderModal()}
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors rounded-none shadow-sm whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Fazer Pedido</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#F5F4F0] hover:text-[#C5A059] transition-colors"
            aria-label="Abrir menu de navegação"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#121214] border-b border-[#262629] px-6 py-8">
          <nav className="flex flex-col gap-6 text-sm uppercase tracking-widest font-medium text-[#D4D4D8]">
            <a 
              href="#sobre" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Sobre a Marca
            </a>
            <a 
              href="#semijoias" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Semijoias Personalizadas
            </a>
            <a 
              href="#saude" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Crachás para Saúde
            </a>
            <a 
              href="#personalizar" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Criar Personalização
            </a>
            <a 
              href="#catalogo" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Catálogo Completo
            </a>
            <a 
              href="#contacto" 
              onClick={() => setMobileMenuOpen(false)}
              className="hover:text-[#C5A059] transition-colors"
            >
              Contactos & Localização
            </a>
          </nav>

          <div className="mt-8 pt-6 border-t border-[#262629] flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenOrderModal();
              }}
              className="w-full py-3 text-center text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors"
            >
              Fazer Encomenda via WhatsApp
            </button>
            <p className="text-xs text-center text-[#71717A] mt-2">
              {STORE_INFO.location}
            </p>
          </div>
        </div>
      )}
    </header>
  );
};
