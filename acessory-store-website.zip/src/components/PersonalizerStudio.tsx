import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { Sparkles, MessageCircle, Check, Stethoscope, Flame, Scale, Pill, Shield, Heart } from 'lucide-react';

interface PersonalizerStudioProps {
  onOpenOrderModal: (customSummary?: string) => void;
}

export const PersonalizerStudio: React.FC<PersonalizerStudioProps> = ({ onOpenOrderModal }) => {
  const [productType, setProductType] = useState<'cracha_saude' | 'cracha_executivo' | 'colar_nome' | 'pulseira_placa' | 'porta_cracha'>('cracha_saude');
  const [nameText, setNameText] = useState('Dra. Sandra Domingos');
  const [subtitleText, setSubtitleText] = useState('Médica Pediatra');
  const [finish, setFinish] = useState<'dourado' | 'prata' | 'rose'>('dourado');
  const [emblem, setEmblem] = useState<'medicina' | 'enfermagem' | 'odontologia' | 'direito' | 'farmacia' | 'nenhum'>('medicina');
  const [fastener, setFastener] = useState<'iman' | 'alfinete'>('iman');

  // Generate a pre-filled WhatsApp message
  const handleOrderCustom = (whatsappNumber: string) => {
    const finishLabel = finish === 'dourado' ? 'Dourado Champagne' : finish === 'prata' ? 'Prata Espelhada' : 'Dourado Rosé';
    const typeLabel = 
      productType === 'cracha_saude' ? 'Crachá de Saúde Personalizado' :
      productType === 'cracha_executivo' ? 'Crachá Profissional Executivo' :
      productType === 'colar_nome' ? 'Colar com Nome Personalizado' :
      productType === 'pulseira_placa' ? 'Pulseira com Placa Gravada' : 'Porta-Crachá Retrátil com Brasão';
    
    const fastenerLabel = fastener === 'iman' ? 'Íman Duplo Neodímio (Não fura roupa)' : 'Alfinete Tradicional';

    const message = encodeURIComponent(
      `Olá ACESSORY STORE! Gostaria de encomendar uma peça personalizada:\n\n` +
      `• *Produto:* ${typeLabel}\n` +
      `• *Nome Gravado:* ${nameText || 'A definir'}\n` +
      `• *Cargo / Especialidade:* ${subtitleText || 'Sem subtítulo'}\n` +
      `• *Acabamento:* ${finishLabel}\n` +
      `• *Símbolo / Brasão:* ${emblem.toUpperCase()}\n` +
      `• *Fixação:* ${fastenerLabel}\n\n` +
      `Por favor, confirmem o valor e o prazo de entrega para Luanda!`
    );

    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  return (
    <section id="personalizar" className="py-24 bg-[#0E0E10] border-t border-[#1F1F24] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
            <Sparkles className="w-4 h-4 text-[#C5A059]" />
            <span>Simulador Interativo de Peça</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light leading-tight mb-4">
            Crie algo que seja seu.
          </h2>
          <p className="text-sm sm:text-base text-[#A1A1AA] leading-relaxed text-balance">
            Personalize seu nome, cargo, acabamento e emblema em tempo real. Cada pedido é verificado e produzido com rigor artesanal em Luanda.
          </p>
        </div>

        {/* 4 Steps Visual Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16 text-center">
          <div className="p-4 bg-[#141416] border border-[#26262B]">
            <span className="text-xs uppercase tracking-widest text-[#C5A059] font-bold block mb-1">Passo 1</span>
            <p className="text-xs font-medium text-[#F4F4F5]">Escolha o Produto</p>
          </div>
          <div className="p-4 bg-[#141416] border border-[#26262B]">
            <span className="text-xs uppercase tracking-widest text-[#C5A059] font-bold block mb-1">Passo 2</span>
            <p className="text-xs font-medium text-[#F4F4F5]">Defina a Personalização</p>
          </div>
          <div className="p-4 bg-[#141416] border border-[#26262B]">
            <span className="text-xs uppercase tracking-widest text-[#C5A059] font-bold block mb-1">Passo 3</span>
            <p className="text-xs font-medium text-[#F4F4F5]">Envie pelo WhatsApp</p>
          </div>
          <div className="p-4 bg-[#141416] border border-[#26262B]">
            <span className="text-xs uppercase tracking-widest text-[#C5A059] font-bold block mb-1">Passo 4</span>
            <p className="text-xs font-medium text-[#F4F4F5]">Receba em Luanda</p>
          </div>
        </div>

        {/* Studio Workspace: Configurator (Left) + Live Preview (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Panel */}
          <div className="lg:col-span-7 bg-[#141417] p-6 sm:p-8 border border-[#27272A] space-y-6">
            
            {/* 1. Item Category */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-3">
                1. Tipo de Peça
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'cracha_saude', label: 'Crachá de Saúde' },
                  { id: 'cracha_executivo', label: 'Crachá Executivo' },
                  { id: 'colar_nome', label: 'Colar com Nome' },
                  { id: 'pulseira_placa', label: 'Pulseira Gravada' },
                  { id: 'porta_cracha', label: 'Roller Clip Retrátil' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setProductType(item.id as any);
                      if (item.id === 'colar_nome' && nameText.startsWith('Dr')) {
                        setNameText('Sandra');
                        setSubtitleText('Inicial S com Ponto de Luz');
                      } else if (item.id === 'cracha_saude' && !nameText.startsWith('Dr')) {
                        setNameText('Dra. Sandra Domingos');
                        setSubtitleText('Médica Pediatra');
                      }
                    }}
                    className={`px-3 py-2.5 text-xs font-medium transition-colors text-left border ${
                      productType === item.id
                        ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F5F4F0]'
                        : 'border-[#27272A] bg-[#18181B] text-[#A1A1AA] hover:text-[#F4F4F5]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Text Input */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Nome ou Iniciais na Peça
                </label>
                <input
                  type="text"
                  value={nameText}
                  onChange={(e) => setNameText(e.target.value)}
                  placeholder="Ex: Dra. Sandra Domingos"
                  maxLength={35}
                  className="w-full bg-[#1A1A1D] border border-[#2E2E33] px-3.5 py-2.5 text-sm text-[#F5F4F0] focus:border-[#C5A059] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Cargo, Especialidade ou Frase
                </label>
                <input
                  type="text"
                  value={subtitleText}
                  onChange={(e) => setSubtitleText(e.target.value)}
                  placeholder="Ex: Médica Cirurgiã / Direito"
                  maxLength={40}
                  className="w-full bg-[#1A1A1D] border border-[#2E2E33] px-3.5 py-2.5 text-sm text-[#F5F4F0] focus:border-[#C5A059] focus:outline-none transition-colors"
                />
              </div>
            </div>

            {/* 3. Metal Finish */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-3">
                Acabamento da Peça
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'dourado', label: 'Dourado Champagne', color: 'bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#AA7C11]' },
                  { id: 'prata', label: 'Prateado Espelho', color: 'bg-gradient-to-r from-slate-200 via-slate-400 to-slate-300' },
                  { id: 'rose', label: 'Dourado Rosé', color: 'bg-gradient-to-r from-rose-200 via-rose-300 to-amber-700' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setFinish(item.id as any)}
                    className={`p-3 border text-left flex items-center gap-3 transition-colors ${
                      finish === item.id
                        ? 'border-[#C5A059] bg-[#C5A059]/10'
                        : 'border-[#27272A] bg-[#18181B] hover:border-[#3F3F46]'
                    }`}
                  >
                    <span className={`w-4 h-4 rounded-full ${item.color} shrink-0 shadow-sm`} />
                    <span className="text-xs font-medium text-[#E4E4E7] truncate">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Emblem Selection */}
            {(productType === 'cracha_saude' || productType === 'cracha_executivo' || productType === 'porta_cracha') && (
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-3">
                  Símbolo ou Brasão
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'medicina', label: 'Medicina (Estetoscópio)', icon: Stethoscope },
                    { id: 'enfermagem', label: 'Enfermagem (Lâmpada)', icon: Flame },
                    { id: 'odontologia', label: 'Odontologia', icon: Sparkles },
                    { id: 'direito', label: 'Direito (Balança)', icon: Scale },
                    { id: 'farmacia', label: 'Farmácia / Bio', icon: Pill },
                    { id: 'nenhum', label: 'Design Limpo / Sem Ícone', icon: Shield },
                  ].map((item) => {
                    const IconComp = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setEmblem(item.id as any)}
                        className={`p-2.5 border text-left flex items-center gap-2 transition-colors ${
                          emblem === item.id
                            ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F4F4F5]'
                            : 'border-[#27272A] bg-[#18181B] text-[#A1A1AA] hover:text-[#F4F4F5]'
                        }`}
                      >
                        <IconComp className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                        <span className="text-xs truncate">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 5. Fastener Choice */}
            {(productType === 'cracha_saude' || productType === 'cracha_executivo') && (
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Tipo de Fixação no Uniforme / Roupa
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFastener('iman')}
                    className={`p-3 border text-left transition-colors ${
                      fastener === 'iman'
                        ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F5F4F0]'
                        : 'border-[#27272A] bg-[#18181B] text-[#A1A1AA]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold">Íman Duplo Neodímio</span>
                      <span className="text-[10px] text-[#C5A059] uppercase">Recomendado</span>
                    </div>
                    <p className="text-[11px] text-[#8E8E93]">Não fura nem puxa fios do jaleco ou camisa social.</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFastener('alfinete')}
                    className={`p-3 border text-left transition-colors ${
                      fastener === 'alfinete'
                        ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F5F4F0]'
                        : 'border-[#27272A] bg-[#18181B] text-[#A1A1AA]'
                    }`}
                  >
                    <span className="text-xs font-semibold block mb-1">Alfinete Tradicional</span>
                    <p className="text-[11px] text-[#8E8E93]">Fixação clássica por presilha de alfinete.</p>
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Live Preview Showcase */}
          <div className="lg:col-span-5 sticky top-28 space-y-6">
            <div className="bg-[#141417] border border-[#27272A] p-6 sm:p-8 flex flex-col items-center justify-center min-h-[380px] relative overflow-hidden">
              <div className="w-full flex items-center justify-between mb-6 pb-3 border-b border-[#26262B] text-xs uppercase tracking-widest text-[#71717A]">
                <span>Pré-Visualização Digital</span>
                <span className="text-[#C5A059] font-medium">Acabamento Real</span>
              </div>

              {/* Realistic Render of Badge or Jewelry Piece */}
              {productType === 'cracha_saude' || productType === 'cracha_executivo' || productType === 'porta_cracha' ? (
                <div 
                  className={`w-full max-w-sm rounded-md p-6 border shadow-2xl relative transition-all duration-300 ${
                    finish === 'dourado'
                      ? 'bg-gradient-to-br from-[#1C180C] via-[#241E10] to-[#12110E] border-[#D4AF37]/50 shadow-[#D4AF37]/10'
                      : finish === 'prata'
                      ? 'bg-gradient-to-br from-[#16171A] via-[#202227] to-[#111214] border-slate-400/50 shadow-slate-500/10'
                      : 'bg-gradient-to-br from-[#201414] via-[#2B1B1C] to-[#150F10] border-rose-400/50 shadow-rose-500/10'
                  }`}
                >
                  {/* Metallic Sheen Effect */}
                  <div className="absolute top-0 right-0 w-32 h-full bg-gradient-to-l from-white/10 to-transparent pointer-events-none transform -skew-x-12" />

                  <div className="flex items-center gap-4">
                    {/* Emblem Icon in metallic circle */}
                    <div 
                      className={`w-12 h-12 rounded-full flex items-center justify-center border shrink-0 ${
                        finish === 'dourado'
                          ? 'border-[#D4AF37] text-[#D4AF37] bg-[#D4AF37]/15'
                          : finish === 'prata'
                          ? 'border-slate-300 text-slate-200 bg-slate-300/15'
                          : 'border-rose-300 text-rose-300 bg-rose-300/15'
                      }`}
                    >
                      {emblem === 'medicina' && <Stethoscope className="w-6 h-6" />}
                      {emblem === 'enfermagem' && <Flame className="w-6 h-6" />}
                      {emblem === 'odontologia' && <Sparkles className="w-6 h-6" />}
                      {emblem === 'direito' && <Scale className="w-6 h-6" />}
                      {emblem === 'farmacia' && <Pill className="w-6 h-6" />}
                      {emblem === 'nenhum' && <Shield className="w-6 h-6" />}
                    </div>

                    {/* Texts */}
                    <div className="overflow-hidden">
                      <h4 
                        className={`font-serif text-lg sm:text-xl font-bold tracking-wide truncate ${
                          finish === 'dourado'
                            ? 'text-[#F5E6B3]'
                            : finish === 'prata'
                            ? 'text-slate-100'
                            : 'text-rose-100'
                        }`}
                      >
                        {nameText || 'Seu Nome Aqui'}
                      </h4>
                      <p className="text-xs uppercase tracking-widest text-[#A1A1AA] truncate mt-0.5">
                        {subtitleText || 'Sua Profissão / Cargo'}
                      </p>
                    </div>
                  </div>

                  {/* Bottom Strip: Attachment & Security Note */}
                  <div className="mt-6 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#71717A]">
                    <span className="uppercase tracking-wider">ACESSORY STORE · LUANDA</span>
                    <span className="text-[#C5A059]">
                      {fastener === 'iman' ? '• Íman Neodímio' : '• Fecho Alfinete'}
                    </span>
                  </div>
                </div>
              ) : (
                /* Jewelry Render (Necklace or Bracelet) */
                <div 
                  className={`w-full max-w-sm rounded-md p-8 border shadow-2xl relative transition-all duration-300 text-center ${
                    finish === 'dourado'
                      ? 'bg-[#181611] border-[#D4AF37]/40 shadow-[#D4AF37]/10'
                      : finish === 'prata'
                      ? 'bg-[#141518] border-slate-400/40 shadow-slate-500/10'
                      : 'bg-[#1C1415] border-rose-400/40 shadow-rose-500/10'
                  }`}
                >
                  {/* Jewelry Chain Graphic */}
                  <div className="w-24 h-6 mx-auto mb-4 border-b-2 border-dashed border-[#C5A059]/40 rounded-b-full" />

                  {/* Nameplate in script */}
                  <div className="py-4">
                    <p 
                      className={`font-serif text-2xl sm:text-3xl italic tracking-wider ${
                        finish === 'dourado'
                          ? 'gold-gradient-text'
                          : finish === 'prata'
                          ? 'text-slate-100'
                          : 'text-rose-200'
                      }`}
                    >
                      {nameText || 'Sandra'}
                    </p>
                    {subtitleText && (
                      <p className="text-xs uppercase tracking-widest text-[#71717A] mt-2">
                        {subtitleText}
                      </p>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#27272A] text-[11px] text-[#71717A] tracking-wider uppercase">
                    Semijoia com Banho Nobre Antialérgico
                  </div>
                </div>
              )}

              {/* Order Actions for WhatsApp Lines */}
              <div className="w-full mt-8 space-y-3">
                <p className="text-xs text-center text-[#A1A1AA]">
                  Clique para enviar este modelo pré-preenchido à nossa equipa:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleOrderCustom(STORE_INFO.whatsapp1.clean)}
                    className="w-full py-3 px-4 text-xs font-semibold uppercase tracking-wider text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" />
                    <span>WhatsApp 941 411 375</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOrderCustom(STORE_INFO.whatsapp2.clean)}
                    className="w-full py-3 px-4 text-xs font-semibold uppercase tracking-wider text-[#E4E4E7] bg-[#1F1F24] hover:bg-[#2A2A30] border border-[#3F3F46] transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0 text-[#C5A059]" />
                    <span>WhatsApp 936 202 630</span>
                  </button>
                </div>

                <p className="text-[11px] text-center text-[#71717A] mt-2">
                  Atendimento direto para Luanda & envios interprovinciais.
                </p>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
