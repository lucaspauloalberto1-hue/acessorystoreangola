import React from 'react';
import { STEPS, STORE_INFO } from '../data/storeData';
import { ArrowRight, Sparkles } from 'lucide-react';

interface OrderingStepsProps {
  onOpenOrderModal: () => void;
}

export const OrderingSteps: React.FC<OrderingStepsProps> = ({ onOpenOrderModal }) => {
  return (
    <section className="py-24 bg-[#0E0E10] border-t border-[#1C1C20]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
            Transparência & Agilidade
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light mb-4">
            Como Funciona a Sua Encomenda
          </h2>
          <p className="text-sm text-[#A1A1AA] leading-relaxed text-balance">
            Criamos uma experiência direta e atenciosa, do primeiro contacto pelo WhatsApp até à entrega da peça pronta em Luanda.
          </p>
        </div>

        {/* 4 Steps Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {STEPS.map((item) => (
            <div
              key={item.step}
              className="p-8 bg-[#141417] border border-[#26262B] relative flex flex-col justify-between"
            >
              <div>
                <span className="font-serif text-4xl text-[#C5A059] font-light block mb-4">
                  0{item.step}
                </span>
                <h3 className="font-serif text-xl text-[#FBFBF9] mb-3">
                  {item.title}
                </h3>
                <p className="text-xs text-[#8E8E93] leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-[#26262B] text-[11px] text-[#71717A] uppercase tracking-wider">
                Etapa {item.step} de 4
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center pt-4">
          <a
            href="#personalizar"
            className="inline-flex items-center gap-3 px-8 py-4 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>Quero Personalizar a Minha Peça</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
