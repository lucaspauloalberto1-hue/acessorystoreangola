import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { MapPin, Phone, MessageCircle, Mail, Send, CheckCircle2, Clock } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [senderName, setSenderName] = useState('');
  const [selectedWhatsApp, setSelectedWhatsApp] = useState<'wa1' | 'wa2'>('wa1');
  const [orderSubject, setOrderSubject] = useState('Crachá Profissional de Saúde');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    const phone = selectedWhatsApp === 'wa1' ? STORE_INFO.whatsapp1.clean : STORE_INFO.whatsapp2.clean;
    const message = encodeURIComponent(
      `Olá ACESSORY STORE! Meu nome é *${senderName || 'Cliente'}*.\n\n` +
      `Gostaria de solicitar orçamento para: *${orderSubject}*\n` +
      `Detalhes / Dúvida: ${notes || 'Solicito informações sobre personalização e valores em Luanda.'}\n\n` +
      `Local de Entrega: Luanda`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
    setSubmitted(true);
  };

  return (
    <section id="contacto" className="py-24 bg-[#0E0E10] border-t border-[#1C1C20] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
            Luanda, Angola
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light mb-4">
            Fale Connosco & Localização
          </h2>
          <p className="text-sm text-[#A1A1AA] leading-relaxed text-balance">
            Entre em contacto direto para tirar dúvidas, solicitar um orçamento personalizado ou encomendar sua peça.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Official Contact Cards */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Location Card */}
            <div className="p-8 bg-[#141417] border border-[#27272A] relative overflow-hidden">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059] shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold block mb-1">
                    Localização da Loja
                  </span>
                  <h3 className="font-serif text-2xl text-[#FBFBF9] mb-1">
                    Rotunda do Camama
                  </h3>
                  <p className="text-sm text-[#D4D4D8]">
                    Luanda, Angola
                  </p>
                  <p className="text-xs text-[#71717A] mt-2">
                    Atendimento presencial com hora marcada e entrega em toda a província de Luanda e províncias vizinhas.
                  </p>
                </div>
              </div>
            </div>

            {/* Dual WhatsApp Official Channels */}
            <div className="p-8 bg-[#141417] border border-[#27272A]">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold block">
                    Linhas de WhatsApp Oficiais
                  </span>
                  <h4 className="font-serif text-xl text-[#FBFBF9]">
                    Atendimento Imediato
                  </h4>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Line 1 */}
                <div className="p-4 bg-[#18181C] border border-[#2B2B30] flex flex-col justify-between">
                  <div>
                    <span className="text-[11px] text-[#A1A1AA] uppercase tracking-wider block mb-1">Linha Principal</span>
                    <p className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp1.display}</p>
                  </div>
                  <a
                    href={STORE_INFO.whatsapp1.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 py-2 px-3 text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors text-center block"
                  >
                    Conversar Linha 1
                  </a>
                </div>

                {/* Line 2 */}
                <div className="p-4 bg-[#18181C] border border-[#2B2B30] flex flex-col justify-between">
                  <div>
                    <span className="text-[11px] text-[#A1A1AA] uppercase tracking-wider block mb-1">Linha Secundária</span>
                    <p className="text-sm font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp2.display}</p>
                  </div>
                  <a
                    href={STORE_INFO.whatsapp2.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 py-2 px-3 text-xs uppercase tracking-wider font-semibold text-[#F4F4F5] bg-[#24242A] hover:bg-[#303038] border border-[#3F3F46] transition-colors text-center block"
                  >
                    Conversar Linha 2
                  </a>
                </div>
              </div>
            </div>

            {/* Email Official */}
            <div className="p-6 bg-[#141417] border border-[#27272A] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059] shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#A1A1AA] block">Gmail Oficial da Empresa</span>
                  <a
                    href={`mailto:${STORE_INFO.email}`}
                    className="text-sm text-[#FBFBF9] hover:text-[#C5A059] transition-colors font-medium"
                  >
                    {STORE_INFO.email}
                  </a>
                </div>
              </div>
              <a
                href={`mailto:${STORE_INFO.email}`}
                className="hidden sm:inline-block px-4 py-2 text-xs uppercase tracking-wider font-semibold text-[#F4F4F5] border border-[#3F3F46] hover:border-[#C5A059] hover:text-[#C5A059] transition-colors"
              >
                Enviar E-mail
              </a>
            </div>

          </div>

          {/* Right Column: Interactive Quick Order Request Form */}
          <div className="lg:col-span-6 bg-[#141417] border border-[#27272A] p-8">
            <h3 className="font-serif text-2xl text-[#FBFBF9] mb-2">
              Envie uma Mensagem de Pedido
            </h3>
            <p className="text-xs text-[#A1A1AA] mb-6">
              Preencha os dados e abra uma conversa formatada no WhatsApp em 1 clique.
            </p>

            {submitted && (
              <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3 text-xs text-emerald-400">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>Conversa iniciada! Nossa equipa em Luanda responderá em breve.</span>
              </div>
            )}

            <form onSubmit={handleSubmitInquiry} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Seu Nome
                </label>
                <input
                  type="text"
                  required
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="Ex: Dra. Maria Silva"
                  className="w-full bg-[#1A1A1D] border border-[#2E2E33] px-4 py-3 text-sm text-[#F5F4F0] focus:border-[#C5A059] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Item de Interesse
                </label>
                <select
                  value={orderSubject}
                  onChange={(e) => setOrderSubject(e.target.value)}
                  className="w-full bg-[#1A1A1D] border border-[#2E2E33] px-4 py-3 text-sm text-[#F5F4F0] focus:border-[#C5A059] focus:outline-none transition-colors"
                >
                  <option value="Crachá Profissional de Saúde (Médico/Enfermagem)">Crachá Profissional de Saúde (Médico/Enfermagem)</option>
                  <option value="Colar Personalizado com Nome em Ouro">Colar Personalizado com Nome</option>
                  <option value="Pulseira com Placa de Identidade">Pulseira com Placa de Identidade</option>
                  <option value="Crachá Corporativo / Direito / Executivo">Crachá Corporativo / Direito / Executivo</option>
                  <option value="Porta-Crachá Retrátil com Brasão">Porta-Crachá Retrátil com Brasão</option>
                  <option value="Encomenda em Lote para Clínica ou Hospital">Encomenda em Lote para Clínica / Hospital</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Escolha o WhatsApp para Atendimento
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedWhatsApp('wa1')}
                    className={`p-3 border text-xs text-left transition-colors ${
                      selectedWhatsApp === 'wa1'
                        ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F5F4F0]'
                        : 'border-[#2E2E33] bg-[#1A1A1D] text-[#A1A1AA]'
                    }`}
                  >
                    <span className="font-semibold block">{STORE_INFO.whatsapp1.display}</span>
                    <span className="text-[11px] text-[#71717A]">Linha 1</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedWhatsApp('wa2')}
                    className={`p-3 border text-xs text-left transition-colors ${
                      selectedWhatsApp === 'wa2'
                        ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#F5F4F0]'
                        : 'border-[#2E2E33] bg-[#1A1A1D] text-[#A1A1AA]'
                    }`}
                  >
                    <span className="font-semibold block">{STORE_INFO.whatsapp2.display}</span>
                    <span className="text-[11px] text-[#71717A]">Linha 2</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold mb-2">
                  Texto ou Detalhes da Gravação
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Informe o nome a ser gravado, profissão ou detalhes adicionais..."
                  className="w-full bg-[#1A1A1D] border border-[#2E2E33] px-4 py-3 text-sm text-[#F5F4F0] focus:border-[#C5A059] focus:outline-none transition-colors"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 px-6 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Enviar Pedido pelo WhatsApp</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
