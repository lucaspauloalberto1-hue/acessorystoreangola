import React from 'react';
import { STORE_INFO } from '../data/storeData';
import { Instagram, Video, Facebook, Mail, MapPin, Phone } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#070708] border-t border-[#1F1F24] text-[#8E8E93] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-12 border-b border-[#1C1C20]">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-2xl font-serif tracking-widest text-[#FBFBF9]">
              ACESSORY STORE
            </h3>
            <p className="text-xs uppercase tracking-widest text-[#C5A059] font-medium">
              Semijoias personalizadas • Design • Personalização
            </p>
            <p className="text-xs text-[#8E8E93] leading-relaxed max-w-sm">
              Criamos semijoias sob encomenda e crachás profissionais de alto padrão para quem valoriza elegância, vocação e identidade em Luanda e em toda Angola.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href={STORE_INFO.social.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#141416] border border-[#27272A] flex items-center justify-center text-[#D4D4D8] hover:text-[#C5A059] hover:border-[#C5A059] transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={STORE_INFO.social.tiktok.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#141416] border border-[#27272A] flex items-center justify-center text-[#D4D4D8] hover:text-[#C5A059] hover:border-[#C5A059] transition-colors"
                aria-label="TikTok"
              >
                <Video className="w-4 h-4" />
              </a>

              <a
                href={STORE_INFO.social.facebook.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#141416] border border-[#27272A] flex items-center justify-center text-[#D4D4D8] hover:text-[#C5A059] hover:border-[#C5A059] transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>

              <a
                href={`mailto:${STORE_INFO.email}`}
                className="w-9 h-9 rounded-full bg-[#141416] border border-[#27272A] flex items-center justify-center text-[#D4D4D8] hover:text-[#C5A059] hover:border-[#C5A059] transition-colors"
                aria-label="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <span className="text-xs uppercase tracking-widest text-[#FBFBF9] font-semibold block mb-4">
              Navegação
            </span>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#" className="hover:text-[#FBFBF9] transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-[#FBFBF9] transition-colors">Sobre Nós</a>
              </li>
              <li>
                <a href="#catalogo" className="hover:text-[#FBFBF9] transition-colors">Coleções & Catálogo</a>
              </li>
              <li>
                <a href="#personalizar" className="hover:text-[#FBFBF9] transition-colors">Personalização Online</a>
              </li>
              <li>
                <a href="#saude" className="hover:text-[#FBFBF9] transition-colors">Crachás de Saúde</a>
              </li>
              <li>
                <a href="#contacto" className="hover:text-[#FBFBF9] transition-colors">Contactos & Pedidos</a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-4 space-y-3">
            <span className="text-xs uppercase tracking-widest text-[#FBFBF9] font-semibold block mb-4">
              Presença & Atendimento
            </span>
            
            <div className="flex items-start gap-2.5 text-xs">
              <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <span>{STORE_INFO.location}</span>
            </div>

            <div className="flex items-start gap-2.5 text-xs">
              <Phone className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <div>
                <p>WhatsApp: {STORE_INFO.whatsapp1.display}</p>
                <p>WhatsApp: {STORE_INFO.whatsapp2.display}</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 text-xs">
              <Mail className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <span>{STORE_INFO.email}</span>
            </div>

            <div className="pt-2 text-xs text-[#71717A]">
              Instagram: <strong className="text-[#C5A059]">{STORE_INFO.social.instagram.handle}</strong>
            </div>
          </div>

        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#52525B] gap-4">
          <p>
            &copy; {new Date().getFullYear()} ACESSORY STORE. Todos os direitos reservados. Luanda, Angola.
          </p>
          <div className="flex items-center gap-4">
            <span>Design & Personalização em Luanda</span>
            <span>·</span>
            <span>Rotunda do Camama</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
