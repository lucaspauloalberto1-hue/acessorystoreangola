import React, { useState } from 'react';
import { PRODUCTS } from '../data/storeData';
import { Product, ProductCategory } from '../types';
import { Eye, MessageCircle, Sparkles } from 'lucide-react';

interface CatalogSectionProps {
  onOpenProductDetails: (product: Product) => void;
  onOpenOrderModal: (productName: string) => void;
}

export const CatalogSection: React.FC<CatalogSectionProps> = ({
  onOpenProductDetails,
  onOpenOrderModal,
}) => {
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('todos');

  const filteredProducts = activeCategory === 'todos' 
    ? PRODUCTS 
    : PRODUCTS.filter((p) => p.category === activeCategory);

  const categories: { id: ProductCategory; label: string }[] = [
    { id: 'todos', label: 'Todas as Peças' },
    { id: 'semijoias', label: 'Semijoias' },
    { id: 'crachas_saude', label: 'Crachás de Saúde' },
    { id: 'crachas_executivos', label: 'Crachás Corporativos' },
    { id: 'personalizados', label: 'Acessórios & Roller Clips' },
  ];

  return (
    <section id="catalogo" className="py-24 bg-[#0B0B0C] border-t border-[#1F1F24]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#26262B]">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
              Coleção & Catálogo Oficial
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#FBFBF9] font-light">
              Catálogo de Peças Exclusivas
            </h2>
          </div>
          <p className="text-xs text-[#8E8E93] max-w-sm mt-3 md:mt-0">
            Cada item é confeccionado sob encomenda em Luanda com personalização a laser e acabamento nobre.
          </p>
        </div>

        {/* Category Filter Tabs (Zero-Pill Discipline: segmented interactive bar) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-colors whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-[#C5A059] text-[#0B0B0C]'
                  : 'bg-[#141416] text-[#A1A1AA] hover:text-[#F4F4F5] border border-[#27272A]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-[#141417] border border-[#26262B] flex flex-col justify-between transition-all duration-300 hover:border-[#C5A059]/50"
            >
              <div>
                {/* Product Image Slot with Styled Container */}
                <div className="relative aspect-[4/3] overflow-hidden bg-[#18181B]">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 filter brightness-95"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />
                  
                  {/* Subtle Category Kicker on Image */}
                  <div className="absolute top-3 left-3">
                    <span className="text-[11px] uppercase tracking-wider text-[#F4F4F5] bg-black/60 backdrop-blur-sm px-2.5 py-1 border border-white/10 font-medium">
                      {product.categoryLabel}
                    </span>
                  </div>
                </div>

                {/* Product Content */}
                <div className="p-6">
                  <div className="flex items-baseline justify-between gap-2 mb-2">
                    <h3 className="font-serif text-xl text-[#FBFBF9] group-hover:text-[#C5A059] transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                  </div>

                  {product.price && (
                    <div className="text-sm font-semibold text-[#C5A059] font-mono tracking-tight mb-2">
                      {product.price}
                    </div>
                  )}
                  
                  <p className="text-xs text-[#A1A1AA] leading-relaxed mb-4 line-clamp-2">
                    {product.shortDescription}
                  </p>

                  <div className="text-[11px] text-[#71717A] flex items-center gap-1.5 pt-3 border-t border-[#26262B]">
                    <Sparkles className="w-3 h-3 text-[#C5A059] shrink-0" />
                    <span className="truncate">{product.materialsNote}</span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-6 pt-0 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => onOpenProductDetails(product)}
                  className="py-2.5 px-3 text-xs uppercase tracking-wider font-medium text-[#D4D4D8] border border-[#3F3F46] hover:border-[#A1A1AA] hover:text-[#FFFFFF] transition-colors flex items-center justify-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Ver Detalhes</span>
                </button>

                <button
                  type="button"
                  onClick={() => onOpenOrderModal(product.name)}
                  className="py-2.5 px-3 text-xs uppercase tracking-wider font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] transition-colors flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Encomendar</span>
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Assistance / Custom Inquiry Notice */}
        <div className="mt-16 p-8 bg-[#141416] border border-[#26262B] flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="font-serif text-xl text-[#FBFBF9] mb-1">
              Deseja um crachá institucional ou lote para toda a sua equipa médica?
            </h4>
            <p className="text-xs text-[#A1A1AA]">
              Atendemos clínicas privadas, hospitais, consultórios e ordens profissionais em Luanda com personalização unificada.
            </p>
          </div>
          <button
            onClick={() => onOpenOrderModal('Orçamento para Equipa / Clínica')}
            className="px-6 py-3 text-xs uppercase tracking-widest font-semibold text-[#0B0B0C] bg-[#C5A059] hover:bg-[#D4AF37] whitespace-nowrap"
          >
            Solicitar Proposta para Equipa
          </button>
        </div>

      </div>
    </section>
  );
};
