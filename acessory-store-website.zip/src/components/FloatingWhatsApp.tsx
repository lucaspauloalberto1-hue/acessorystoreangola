import React, { useState } from 'react';
import { STORE_INFO } from '../data/storeData';
import { MessageCircle, X, ChevronUp, ShieldCheck } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [open, setOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Popover Options */}
      {open && (
        <div className="mb-3 w-72 bg-[#141417] border border-[#2B2B30] shadow-2xl p-4 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#26262B]">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs uppercase tracking-wider font-semibold text-[#F4F4F5]">
                ACESSORY STORE
              </span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-[#71717A] hover:text-white"
              aria-label="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-[#A1A1AA] mb-3">
            Escolha uma de nossas linhas diretas de atendimento em Luanda:
          </p>

          <div className="space-y-2">
            <a
              href={STORE_INFO.whatsapp1.link}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 bg-[#1F1F24] hover:bg-[#2A2A32] border border-[#383840] transition-colors flex items-center justify-between group block text-xs"
            >
              <div>
                <span className="text-[10px] uppercase tracking-wider text-[#A1A1AA] block">Linha 1</span>
                <span className="font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp1.display}</span>
              </div>
              <MessageCircle className="w-4 h-4 text-emerald-400" />
            </a>

            <a
              href={STORE_INFO.whatsapp2.link}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 bg-[#1F1F24] hover:bg-[#2A2A32] border border-[#383840] transition-colors flex items-center justify-between group block text-xs"
            >
              <div>
                <span className="text-[10px] uppercase tracking-wider text-[#A1A1AA] block">Linha 2</span>
                <span className="font-semibold text-[#F4F4F5]">{STORE_INFO.whatsapp2.display}</span>
              </div>
              <MessageCircle className="w-4 h-4 text-emerald-400" />
            </a>
          </div>

          <div className="mt-3 pt-2 border-t border-[#26262B] text-[10px] text-center text-[#71717A]">
            Rotunda do Camama · Luanda
          </div>
        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setOpen(!open)}
        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-black shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-105"
        aria-label="Abrir WhatsApp oficial"
      >
        {open ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>
    </div>
  );
};
